browser.runtime.onInstalled.addListener(() => {
  // BugSnap extension installed
});

// Handle messages from content scripts
browser.runtime.onMessage.addListener((request, sender) => {
  if (request.action === 'fetchProjects') {
    return fetchProjects(request.token);
  }

  if (request.action === 'fetchNextTaskNumber') {
    return fetchNextTaskNumber(request.token, request.projectId);
  }

  if (request.action === 'fetchProjectMembers') {
    return fetchProjectMembers(request.token, request.projectId);
  }

  if (request.action === 'createTask') {
    return createTask(request.token, request.payload);
  }

  if (request.action === 'uploadRecording') {
    return uploadRecording(request.token, request.issueId, request.recordingBase64);
  }

  if (request.action === 'fetchProjectIssues') {
    return fetchProjectIssues(request.token, request.projectId);
  }

  if (request.action === 'fetchIssueComments') {
    return fetchIssueComments(request.token, request.issueId);
  }

  if (request.action === 'addIssueComment') {
    return addIssueComment(request.token, request.issueId, request.content, request.mentionedUserIds);
  }

  if (request.action === 'fetchProjectMentionable') {
    return fetchProjectMentionable(request.token, request.projectId);
  }

  if (request.action === 'updateIssueStatus') {
    return updateIssueStatus(request.token, request.issueId, request.status);
  }

  if (request.action === 'updateIssueAnnotations') {
    return updateIssueAnnotations(request.token, request.issueId, request.annotations, request.screenshotUrl, request.rawScreenshotUrl);
  }

  if (request.action === 'fetchIssueDetail') {
    return fetchIssueDetail(request.token, request.issueId);
  }

  if (request.action === 'fetchImageAsDataUrl') {
    return fetchImageAsDataUrl(request.url);
  }

  if (request.action === 'captureScreenshot') {
    return browser.tabs.captureVisibleTab(null, { format: 'png' }).then((dataUrl) => {
      return { screenshot: dataUrl };
    });
  }

  if (request.action === 'setUserEmail') {
    browser.storage.local.set({ userEmail: request.email });
  } else if (request.action === 'clearUserEmail') {
    browser.storage.local.remove('userEmail');
  } else if (request.action === 'setToken') {
    browser.storage.local.set({ token: request.token });
  } else if (request.action === 'clearToken') {
    browser.storage.local.remove('token');
  }

  return Promise.resolve();
});

async function fetchProjects(token) {
  const response = await fetch(`${BUGSNAP_API_URL}/api/projects`, {
    headers: {
      'Authorization': `Bearer ${token}`,
      'X-Requested-With': 'BugSnap'
    }
  });

  if (!response.ok) {
    throw new Error(`Failed to fetch projects: ${response.status}`);
  }

  const projects = await response.json();
  return { projects };
}

async function fetchNextTaskNumber(token, projectId) {
  const response = await fetch(`${BUGSNAP_API_URL}/api/projects/${projectId}/next-issue-number`, {
    method: 'GET',
    headers: {
      'Authorization': `Bearer ${token}`,
      'X-Requested-With': 'BugSnap'
    }
  });

  if (!response.ok) {
    throw new Error(`Failed to fetch next task number: ${response.status}`);
  }

  const data = await response.json();
  return { nextTaskNumber: data.nextTaskNumber };
}

async function fetchProjectMembers(token, projectId) {
  const response = await fetch(`${BUGSNAP_API_URL}/api/projects/${projectId}/members`, {
    method: 'GET',
    headers: {
      'Authorization': `Bearer ${token}`,
      'X-Requested-With': 'BugSnap'
    }
  });

  if (!response.ok) {
    throw new Error(`Failed to fetch project members: ${response.status}`);
  }

  const members = await response.json();
  const membersList = members.map(member => ({
    id: member.user.id,
    name: member.user.name,
    email: member.user.email
  }));
  return { members: membersList };
}

async function createTask(token, payload) {
  const response = await fetch(`${BUGSNAP_API_URL}/api/issues`, {
    method: 'POST',
    headers: {
      'Content-Type': 'application/json',
      'Authorization': `Bearer ${token}`,
      'X-Requested-With': 'BugSnap'
    },
    body: JSON.stringify(payload)
  });

  if (!response.ok) {
    const errorData = await response.json();
    throw new Error(errorData.error || 'Failed to create task');
  }

  const task = await response.json();
  return { task };
}

async function fetchIssueDetail(token, issueId) {
  const response = await fetch(`${BUGSNAP_API_URL}/api/issues/${issueId}`, {
    headers: {
      'Authorization': `Bearer ${token}`,
      'X-Requested-With': 'BugSnap'
    }
  });
  if (!response.ok) throw new Error(`Failed to fetch issue: ${response.status}`);
  const issue = await response.json();
  return { issue };
}

async function fetchImageAsDataUrl(url) {
  const response = await fetch(url);
  if (!response.ok) throw new Error(`Failed to fetch image: ${response.status}`);
  const blob = await response.blob();
  const arrayBuffer = await blob.arrayBuffer();
  const bytes = new Uint8Array(arrayBuffer);
  let binary = '';
  for (let i = 0; i < bytes.length; i++) {
    binary += String.fromCharCode(bytes[i]);
  }
  const base64 = btoa(binary);
  const mimeType = blob.type || 'image/png';
  return { dataUrl: `data:${mimeType};base64,${base64}` };
}

async function fetchIssueComments(token, issueId) {
  const response = await fetch(`${BUGSNAP_API_URL}/api/issues/${issueId}/comments`, {
    headers: {
      'Authorization': `Bearer ${token}`,
      'X-Requested-With': 'BugSnap'
    }
  });
  if (!response.ok) throw new Error(`Failed to fetch comments: ${response.status}`);
  const comments = await response.json();
  return { comments };
}

async function addIssueComment(token, issueId, content, mentionedUserIds) {
  const body = { content };
  if (mentionedUserIds && mentionedUserIds.length > 0) {
    body.mentionedUserIds = mentionedUserIds;
  }
  const response = await fetch(`${BUGSNAP_API_URL}/api/issues/${issueId}/comments`, {
    method: 'POST',
    headers: {
      'Content-Type': 'application/json',
      'Authorization': `Bearer ${token}`,
      'X-Requested-With': 'BugSnap'
    },
    body: JSON.stringify(body)
  });
  if (!response.ok) {
    const errorData = await response.json();
    throw new Error(errorData.error || 'Failed to add comment');
  }
  const comment = await response.json();
  return { comment };
}

async function fetchProjectMentionable(token, projectId) {
  const response = await fetch(`${BUGSNAP_API_URL}/api/projects/${projectId}/mentionable`, {
    headers: {
      'Authorization': `Bearer ${token}`,
      'X-Requested-With': 'BugSnap'
    }
  });
  if (!response.ok) throw new Error(`Failed to fetch mentionable users: ${response.status}`);
  const members = await response.json();
  return { members };
}

async function updateIssueStatus(token, issueId, status) {
  const response = await fetch(`${BUGSNAP_API_URL}/api/issues/${issueId}`, {
    method: 'PATCH',
    headers: {
      'Content-Type': 'application/json',
      'Authorization': `Bearer ${token}`,
      'X-Requested-With': 'BugSnap'
    },
    body: JSON.stringify({ status })
  });
  if (!response.ok) {
    const errorData = await response.json();
    throw new Error(errorData.error || 'Failed to update status');
  }
  const issue = await response.json();
  return { issue };
}

async function updateIssueAnnotations(token, issueId, annotations, screenshotUrl, rawScreenshotUrl) {
  const body = { annotations };
  if (screenshotUrl) body.screenshotUrl = screenshotUrl;
  if (rawScreenshotUrl) body.rawScreenshotUrl = rawScreenshotUrl;
  const response = await fetch(`${BUGSNAP_API_URL}/api/issues/${issueId}`, {
    method: 'PATCH',
    headers: {
      'Content-Type': 'application/json',
      'Authorization': `Bearer ${token}`,
      'X-Requested-With': 'BugSnap'
    },
    body: JSON.stringify(body)
  });
  if (!response.ok) {
    const errorData = await response.json();
    throw new Error(errorData.error || 'Failed to update annotations');
  }
  const issue = await response.json();
  return { issue };
}

async function fetchProjectIssues(token, projectId) {
  const response = await fetch(`${BUGSNAP_API_URL}/api/projects/${projectId}/issues`, {
    method: 'GET',
    headers: {
      'Authorization': `Bearer ${token}`,
      'X-Requested-With': 'BugSnap'
    }
  });

  if (!response.ok) {
    throw new Error(`Failed to fetch project issues: ${response.status}`);
  }

  const issues = await response.json();
  return { issues };
}

async function uploadRecording(token, issueId, base64Data) {
  const byteChars = atob(base64Data);
  const byteNumbers = new Array(byteChars.length);
  for (let i = 0; i < byteChars.length; i++) {
    byteNumbers[i] = byteChars.charCodeAt(i);
  }
  const byteArray = new Uint8Array(byteNumbers);
  const blob = new Blob([byteArray], { type: 'video/webm' });

  const formData = new FormData();
  formData.append('file', blob, `recording-${Date.now()}.webm`);

  const response = await fetch(`${BUGSNAP_API_URL}/api/issues/${issueId}/attachments`, {
    method: 'POST',
    headers: {
      'Authorization': `Bearer ${token}`,
      'X-Requested-With': 'BugSnap',
    },
    body: formData,
  });

  if (!response.ok) {
    const errorData = await response.json();
    throw new Error(errorData.error || 'Failed to upload recording');
  }

  const attachment = await response.json();
  return { attachment };
}
