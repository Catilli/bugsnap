// BugSnap UI - Element tagging and screenshot capture
// This file creates the overlay UI elements using vanilla JavaScript

class BugSnapUI {
  // mode: 'tasks-only' (just tasks button/drawer) or 'full' (tagging + tasks)
  constructor(project, mode = 'full') {
    this.project = project;
    this.mode = mode;
    this.isTagging = false;
    this.selectedElement = null;
    this.screenshot = null;
    this.annotations = [];
    this.selectedAnnotationIndex = null;
    this.currentTool = 'rectangle';
    this.userEmail = null;
    this.recording = null;
    this.mediaRecorder = null;
    this.recordedChunks = [];
    this.recordingStartTime = null;
    this.recordingTimerInterval = null;

    // Tasks drawer state
    this.tasksDrawerOpen = false;
    this.tasks = [];
    this.currentPageTasks = [];
    this.selectedTaskId = null;
    this.taskPinMarkers = [];
    this.tasksButton = null;
    this.tasksDrawer = null;
    this.tasksDrawerBackdrop = null;
    this.tasksLoading = false;
    this.tasksKeydownHandler = null;
    this.tasksFilter = 'page'; // 'page' or 'all'

    this.init();
  }

  init() {
    // Load reporter email from storage
    chrome.storage.local.get(['userEmail'], (result) => {
      this.userEmail = result.userEmail || null;
    });
    // Always create the tasks button
    this.createTasksButton();

    if (this.mode === 'full') {
      // Hide tasks button and start tagging (crosshair) mode
      if (this.tasksButton) this.tasksButton.style.display = 'none';
      this.startTagging();
    }
  }

  // Switch from tasks-only to full mode (called when Enable is clicked)
  enableTagging() {
    this.mode = 'full';
    if (this.tasksButton) this.tasksButton.style.display = 'none';
    // Close drawer if open
    if (this.tasksDrawerOpen) this.closeTasksDrawer();
    this.startTagging();
  }

  // Switch from full mode back to tasks-only (called when Disable is clicked)
  disableTagging() {
    this.mode = 'tasks-only';
    // Remove tagging listeners
    if (this.hoverHandler) {
      document.removeEventListener('mousemove', this.hoverHandler, true);
      this.hoverHandler = null;
    }
    if (this.tagClickHandler) {
      document.removeEventListener('click', this.tagClickHandler, true);
      this.tagClickHandler = null;
    }
    // Remove tagging overlay
    const overlay = document.getElementById('bugsnap-tagging-overlay');
    if (overlay) overlay.remove();
    // Remove annotation/task modals
    const annotationModal = document.getElementById('bugsnap-annotation-modal');
    if (annotationModal) annotationModal.remove();
    const taskModal = document.getElementById('bugsnap-task-modal');
    if (taskModal) taskModal.remove();
    // Reset element highlights
    if (this.selectedElement) {
      this.selectedElement.style.outline = '';
      this.selectedElement.style.outlineOffset = '';
      this.selectedElement = null;
    }
    if (this.hoveredElement) {
      this.hoveredElement.style.outline = '';
      this.hoveredElement.style.outlineOffset = '';
      this.hoveredElement = null;
    }
    // Remove pin marker from tagging
    if (this.pinMarker) {
      this.pinMarker.remove();
      this.pinMarker = null;
    }
    // Restore body state
    document.body.style.cursor = '';
    document.body.style.overflow = '';
    this.isTagging = false;
    this.screenshot = null;
    this.annotations = [];
    // Clean up recording
    if (this.mediaRecorder && this.mediaRecorder.state === 'recording') {
      this.mediaRecorder.stop();
    }
    if (this.mediaRecorder && this.mediaRecorder.stream) {
      this.mediaRecorder.stream.getTracks().forEach(track => track.stop());
    }
    if (this.recordingTimerInterval) {
      clearInterval(this.recordingTimerInterval);
      this.recordingTimerInterval = null;
    }
    // Re-show tasks button
    if (this.tasksButton) this.tasksButton.style.display = '';
  }

  // --- XSS prevention ---
  // Uses DOM text node creation to safely escape HTML entities.
  // All API-sourced strings (task titles, descriptions, user names)
  // are passed through this before innerHTML insertion.

  escapeHtml(str) {
    if (!str) return '';
    const div = document.createElement('div');
    div.appendChild(document.createTextNode(str));
    return div.innerHTML;
  }

  // --- URL normalization for matching ---

  normalizeUrl(url) {
    if (!url) return '';
    try {
      const u = new URL(url);
      // Strip hash and trailing slash
      let normalized = u.origin + u.pathname.replace(/\/+$/, '') + u.search;
      return normalized;
    } catch {
      return url.replace(/\/+$/, '').replace(/#.*$/, '');
    }
  }

  // --- Check if event target is a BugSnap UI element ---

  isBugSnapElement(el) {
    if (!el) return false;
    // Walk up the DOM to check for BugSnap containers
    let node = el;
    while (node && node !== document.body) {
      if (node.id && (
        node.id === 'bugsnap-tasks-button' ||
        node.id === 'bugsnap-tasks-drawer' ||
        node.id === 'bugsnap-tasks-backdrop' ||
        node.id === 'bugsnap-annotation-modal' ||
        node.id === 'bugsnap-task-modal'
      )) return true;
      if (node.classList && (
        node.classList.contains('bugsnap-task-pin')
      )) return true;
      node = node.parentElement;
    }
    return false;
  }

  startTagging() {
    this.isTagging = true;
    this.hoveredElement = null;
    document.body.style.cursor = 'crosshair';

    // Add overlay
    const overlay = document.createElement('div');
    overlay.id = 'bugsnap-tagging-overlay';
    overlay.style.cssText = `
      position: fixed;
      top: 0;
      left: 0;
      width: 100%;
      height: 100%;
      background: rgba(0, 0, 0, 0.1);
      z-index: 999998;
      cursor: crosshair;
      pointer-events: none;
    `;
    document.body.appendChild(overlay);

    // Add hover listener for element highlighting
    this.hoverHandler = (e) => this.handleElementHover(e);
    document.addEventListener('mousemove', this.hoverHandler, true);

    // Add click listener
    this.tagClickHandler = (e) => this.handleElementTag(e);
    document.addEventListener('click', this.tagClickHandler, true);
  }

  handleElementHover(e) {
    if (!this.isTagging) return;
    // Skip BugSnap UI elements
    if (this.isBugSnapElement(e.target)) return;

    // Remove previous highlight
    if (this.hoveredElement) {
      this.hoveredElement.style.outline = '';
      this.hoveredElement.style.outlineOffset = '';
    }

    // Highlight current element
    this.hoveredElement = e.target;
    this.hoveredElement.style.outline = '3px solid #3b82f6';
    this.hoveredElement.style.outlineOffset = '2px';
  }

  getCssSelector(el) {
    if (!el || el === document.body || el === document.documentElement) return 'body';
    if (el.id) return '#' + CSS.escape(el.id);

    const parts = [];
    let current = el;
    while (current && current !== document.body && current !== document.documentElement) {
      if (current.id) {
        parts.unshift('#' + CSS.escape(current.id));
        break;
      }
      let tag = current.tagName.toLowerCase();
      // Add classes, filtering out bugsnap-injected ones
      const classes = Array.from(current.classList || [])
        .filter(c => !c.startsWith('bugsnap'))
        .map(c => '.' + CSS.escape(c))
        .join('');
      // nth-of-type for uniqueness among siblings
      const parent = current.parentElement;
      if (parent) {
        const siblings = Array.from(parent.children).filter(s => s.tagName === current.tagName);
        if (siblings.length > 1) {
          const index = siblings.indexOf(current) + 1;
          tag += classes + ':nth-of-type(' + index + ')';
        } else {
          tag += classes;
        }
      } else {
        tag += classes;
      }
      parts.unshift(tag);
      current = current.parentElement;
    }
    return parts.join(' > ');
  }

  handleElementTag(e) {
    if (!this.isTagging) return;
    // Skip BugSnap UI elements
    if (this.isBugSnapElement(e.target)) return;

    e.preventDefault();
    e.stopPropagation();

    this.selectedElement = e.target;
    this.clickX = e.clientX;
    this.clickY = e.clientY;
    this.isTagging = false;
    document.body.style.cursor = 'default';

    // Keep the highlight on selected element
    this.selectedElement.style.outline = '3px solid #3b82f6';
    this.selectedElement.style.outlineOffset = '2px';

    // Add pin marker at click coordinates
    this.addPinMarker(e.clientX, e.clientY);

    // Remove overlay and listeners
    const overlay = document.getElementById('bugsnap-tagging-overlay');
    if (overlay) overlay.remove();
    document.removeEventListener('click', this.tagClickHandler, true);
    document.removeEventListener('mousemove', this.hoverHandler, true);

    // Capture screenshot after a brief delay to ensure highlight is rendered
    setTimeout(() => this.captureScreenshot(), 300);
  }

  addPinMarker(clickX, clickY) {
    // Remove any existing pin (ensure only one pin at a time)
    if (this.pinMarker) {
      this.pinMarker.remove();
      this.pinMarker = null;
    }

    const pin = document.createElement('div');
    pin.className = 'bugsnap-pin';
    pin.style.cssText = `
      position: fixed;
      top: ${clickY - 24}px;
      left: ${clickX - 4}px;
      width: 24px;
      height: 24px;
      background: #ef4444;
      border-radius: 50% 50% 50% 0;
      transform: rotate(-45deg);
      z-index: 10000000;
      box-shadow: 0 2px 4px rgba(0,0,0,0.3);
      pointer-events: none;
    `;
    const inner = document.createElement('div');
    inner.style.cssText = `
      width: 10px;
      height: 10px;
      background: white;
      border-radius: 50%;
      position: absolute;
      top: 50%;
      left: 50%;
      transform: translate(-50%, -50%);
    `;
    pin.appendChild(inner);
    document.body.appendChild(pin);
    this.pinMarker = pin;
  }

  async captureScreenshot() {
    try {
      // Small delay to ensure element highlight is rendered
      await new Promise(resolve => setTimeout(resolve, 100));

      // Use chrome.runtime.sendMessage to capture screenshot
      chrome.runtime.sendMessage({ action: 'captureScreenshot' }, (response) => {
        if (chrome.runtime.lastError) {
          alert('Failed to capture screenshot: ' + chrome.runtime.lastError.message);
          return;
        }

        if (response && response.screenshot) {
          this.screenshot = response.screenshot;
          this.showAnnotationModal();
        } else {
          alert('Failed to capture screenshot - no image received');
        }
      });
    } catch (error) {
      alert('Failed to capture screenshot: ' + error.message);
    }
  }

  showAnnotationModal() {
    // Hide pin marker — it's already captured in the screenshot image,
    // no need to show the DOM element on top of the modal
    if (this.pinMarker) {
      this.pinMarker.style.display = 'none';
    }

    // Hide tasks button and close drawer during annotation
    if (this.tasksButton) this.tasksButton.style.display = 'none';
    if (this.tasksDrawerOpen) this.closeTasksDrawer();

    // Disable page scrolling
    document.body.style.overflow = 'hidden';

    const modal = document.createElement('div');
    modal.id = 'bugsnap-annotation-modal';
    modal.style.cssText = `
      position: fixed;
      top: 0;
      left: 0;
      width: 100vw;
      height: 100vh;
      background: #1f2937;
      z-index: 9999999;
      display: flex;
      flex-direction: column;
    `;

    // Toolbar (top) - horizontal design
    const toolbar = document.createElement('div');
    toolbar.style.cssText = `
      height: 60px;
      background: white;
      display: flex;
      align-items: center;
      padding: 0 16px;
      gap: 8px;
      box-shadow: 0 2px 4px rgba(0, 0, 0, 0.1);
    `;

    // Toolbar innerHTML contains only static SVG icons and UI chrome — no API-sourced data
    toolbar.innerHTML = `
      <!-- Select Tool -->
      <button class="tool-btn" data-tool="cursor" style="
        background: #f3f4f6;
        border: 1px solid #e5e7eb;
        padding: 8px;
        border-radius: 4px;
        cursor: pointer;
        display: flex;
        align-items: center;
        justify-content: center;
      " title="Select">
        <svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="#6b7280" stroke-width="2"><path d="M3 3l7.07 16.97 2.51-7.39 7.39-2.51L3 3z"/><path d="M13 13l6 6"/></svg>
      </button>

      <!-- Pen Tool -->
      <button class="tool-btn" data-tool="pen" style="
        background: white;
        border: 1px solid #e5e7eb;
        padding: 8px;
        border-radius: 4px;
        cursor: pointer;
        display: flex;
        align-items: center;
        justify-content: center;
      " title="Pen">
        <svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="#6b7280" stroke-width="2"><path d="M17 3a2.85 2.83 0 1 1 4 4L7.5 20.5 2 22l1.5-5.5Z"/></svg>
      </button>

      <!-- Rectangle Tool -->
      <button class="tool-btn active" data-tool="rectangle" style="
        background: #3b82f6;
        border: 1px solid #3b82f6;
        padding: 8px;
        border-radius: 4px;
        cursor: pointer;
        display: flex;
        align-items: center;
        justify-content: center;
      " title="Rectangle">
        <svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="white" stroke-width="2"><rect width="18" height="18" x="3" y="3" rx="2"/></svg>
      </button>

      <!-- Highlighter Tool -->
      <button class="tool-btn" data-tool="highlighter" style="
        background: white;
        border: 1px solid #e5e7eb;
        padding: 8px;
        border-radius: 4px;
        cursor: pointer;
        display: flex;
        align-items: center;
        justify-content: center;
      " title="Highlighter">
        <svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="#6b7280" stroke-width="2"><rect width="18" height="8" x="3" y="8" rx="1" fill="#6b7280" fill-opacity="0.3" stroke="none"/><rect width="18" height="8" x="3" y="8" rx="1"/></svg>
      </button>

      <!-- Arrow Tool -->
      <button class="tool-btn" data-tool="arrow" style="
        background: white;
        border: 1px solid #e5e7eb;
        padding: 8px;
        border-radius: 4px;
        cursor: pointer;
        display: flex;
        align-items: center;
        justify-content: center;
      " title="Arrow">
        <svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="#6b7280" stroke-width="2"><line x1="5" y1="12" x2="19" y2="12"/><polyline points="12 5 19 12 12 19"/></svg>
      </button>

      <!-- Text Tool -->
      <button class="tool-btn" data-tool="text" style="
        background: white;
        border: 1px solid #e5e7eb;
        padding: 8px;
        border-radius: 4px;
        cursor: pointer;
        display: flex;
        align-items: center;
        justify-content: center;
      " title="Text">
        <svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="#6b7280" stroke-width="2"><polyline points="4 7 4 4 20 4 20 7"/><line x1="9" x2="15" y1="20" y2="20"/><line x1="12" x2="12" y1="4" y2="20"/></svg>
      </button>

      <!-- Divider -->
      <div style="width: 1px; height: 24px; background: #e5e7eb; margin: 0 4px;"></div>

      <!-- Stroke Width -->
      <select id="bugsnap-stroke-width" style="
        padding: 6px 8px;
        border: 1px solid #e5e7eb;
        border-radius: 4px;
        font-size: 13px;
        background: white;
        cursor: pointer;
        color: #374151;
      " title="Stroke Width">
        <option value="1">1px</option>
        <option value="2" selected>2px</option>
        <option value="3">3px</option>
        <option value="4">4px</option>
        <option value="5">5px</option>
      </select>

      <!-- Divider -->
      <div style="width: 1px; height: 24px; background: #e5e7eb; margin: 0 4px;"></div>

      <!-- Color Selector -->
      <div style="display: flex; gap: 6px; align-items: center;">
        <button class="color-btn" data-color="#ef4444" style="
          width: 28px;
          height: 28px;
          border-radius: 4px;
          background: #ef4444;
          border: 2px solid #fff;
          cursor: pointer;
          box-shadow: 0 0 0 1px #e5e7eb;
        " title="Red"></button>
        <button class="color-btn" data-color="#3b82f6" style="
          width: 28px;
          height: 28px;
          border-radius: 4px;
          background: #3b82f6;
          border: 2px solid #fff;
          cursor: pointer;
          box-shadow: 0 0 0 1px #e5e7eb;
        " title="Blue"></button>
        <button class="color-btn" data-color="#10b981" style="
          width: 28px;
          height: 28px;
          border-radius: 4px;
          background: #10b981;
          border: 2px solid #fff;
          cursor: pointer;
          box-shadow: 0 0 0 1px #e5e7eb;
        " title="Green"></button>
        <button class="color-btn" data-color="#f59e0b" style="
          width: 28px;
          height: 28px;
          border-radius: 4px;
          background: #f59e0b;
          border: 2px solid #fff;
          cursor: pointer;
          box-shadow: 0 0 0 1px #e5e7eb;
        " title="Yellow"></button>
        <button class="color-btn" data-color="#8b5cf6" style="
          width: 28px;
          height: 28px;
          border-radius: 4px;
          background: #8b5cf6;
          border: 2px solid #fff;
          cursor: pointer;
          box-shadow: 0 0 0 1px #e5e7eb;
        " title="Purple"></button>
      </div>

      <!-- Divider -->
      <div style="width: 1px; height: 24px; background: #e5e7eb; margin: 0 4px;"></div>

      <!-- Undo -->
      <button id="bugsnap-undo" style="
        background: white;
        border: 1px solid #e5e7eb;
        padding: 8px;
        border-radius: 4px;
        cursor: pointer;
        display: flex;
        align-items: center;
        justify-content: center;
        transition: background 0.2s, border-color 0.2s;
      " title="Undo (Ctrl+Z)"
      onmouseover="this.style.background='#f3f4f6'; this.style.borderColor='#d1d5db'"
      onmouseout="this.style.background='white'; this.style.borderColor='#e5e7eb'">
        <svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="#6b7280" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M9 14 4 9l5-5"/><path d="M4 9h10.5a5.5 5.5 0 0 1 5.5 5.5a5.5 5.5 0 0 1-5.5 5.5H11"/></svg>
      </button>

      <!-- Redo -->
      <button id="bugsnap-redo" style="
        background: white;
        border: 1px solid #e5e7eb;
        padding: 8px;
        border-radius: 4px;
        cursor: pointer;
        display: flex;
        align-items: center;
        justify-content: center;
        transition: background 0.2s, border-color 0.2s;
      " title="Redo (Ctrl+Y)"
      onmouseover="this.style.background='#f3f4f6'; this.style.borderColor='#d1d5db'"
      onmouseout="this.style.background='white'; this.style.borderColor='#e5e7eb'">
        <svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="#6b7280" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="m15 14 5-5-5-5"/><path d="M20 9H9.5A5.5 5.5 0 0 0 4 14.5A5.5 5.5 0 0 0 9.5 20H13"/></svg>
      </button>

      <!-- Delete -->
      <button id="bugsnap-delete-annotation" style="
        background: white;
        border: 1px solid #e5e7eb;
        padding: 8px;
        border-radius: 4px;
        cursor: pointer;
        display: flex;
        align-items: center;
        justify-content: center;
      " title="Delete Selected">
        <svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="#6b7280" stroke-width="2"><path d="M3 6h18"/><path d="M19 6v14c0 1-1 2-2 2H7c-1 0-2-1-2-2V6"/><path d="M8 6V4c0-1 1-2 2-2h4c1 0 2 1 2 2v2"/></svg>
      </button>

      <!-- Divider -->
      <div style="width: 1px; height: 24px; background: #e5e7eb; margin: 0 4px;"></div>

      <!-- Record Screen Button -->
      <button id="bugsnap-record-btn" style="
        background: white;
        border: 1px solid #e5e7eb;
        color: #6b7280;
        padding: 8px 12px;
        border-radius: 4px;
        cursor: pointer;
        display: flex;
        align-items: center;
        gap: 6px;
        font-size: 13px;
        font-weight: 500;
        transition: background 0.2s;
      " title="Record Screen">
        <svg width="16" height="16" viewBox="0 0 24 24" fill="#ef4444" stroke="none"><circle cx="12" cy="12" r="7"/></svg>
        <span>Record</span>
      </button>

      <!-- Spacer -->
      <div style="flex: 1;"></div>

      <!-- Save as Task Button -->
      <button id="bugsnap-save-annotation" style="
        background: #10b981;
        border: 1px solid #10b981;
        color: white;
        padding: 8px 16px;
        border-radius: 4px;
        cursor: pointer;
        display: flex;
        align-items: center;
        gap: 6px;
        font-size: 14px;
        font-weight: 500;
      " title="Save as Task">
        <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M15.2 3a2 2 0 0 1 1.4.6l3.8 3.8a2 2 0 0 1 .6 1.4V19a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2V5a2 2 0 0 1 2-2z"/><path d="M17 21v-7a1 1 0 0 0-1-1H8a1 1 0 0 0-1 1v7"/><path d="M7 3v4a1 1 0 0 0 1 1h8"/></svg>
        <span>Save as Task</span>
      </button>

      <!-- Cancel Button -->
      <button id="bugsnap-cancel-annotation" style="
        background: white;
        border: 1px solid #e5e7eb;
        color: #6b7280;
        padding: 8px 16px;
        border-radius: 4px;
        cursor: pointer;
        display: flex;
        align-items: center;
        gap: 6px;
        font-size: 14px;
        font-weight: 500;
      " title="Cancel">
        <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M18 6 6 18"/><path d="m6 6 12 12"/></svg>
        <span>Cancel</span>
      </button>
    `;

    // Screenshot container (below toolbar)
    const screenshotContainer = document.createElement('div');
    screenshotContainer.id = 'bugsnap-screenshot-container';
    screenshotContainer.style.cssText = `
      flex: 1;
      display: flex;
      align-items: center;
      justify-content: center;
      padding: 20px;
      position: relative;
      overflow: auto;
    `;

    // Screenshot src is a data URL from captureVisibleTab, not API-sourced user content
    const screenshotDiv = document.createElement('div');
    screenshotDiv.style.cssText = 'position: relative; max-width: 100%; max-height: 100%;';
    const screenshotImg = document.createElement('img');
    screenshotImg.id = 'bugsnap-screenshot';
    screenshotImg.src = this.screenshot;
    screenshotImg.style.cssText = 'max-width: 100%; max-height: calc(100vh - 100px); display: block;';
    screenshotDiv.appendChild(screenshotImg);
    screenshotContainer.appendChild(screenshotDiv);

    modal.appendChild(toolbar);
    modal.appendChild(screenshotContainer);
    document.body.appendChild(modal);

    // Initialize MarkMyImage annotation library
    setTimeout(() => {
      this.markMyImage = new MarkMyImage(screenshotDiv, {
        strokeColor: '#ef4444',
        strokeWidth: 2,
        fillColor: 'rgba(239, 68, 68, 0.1)',
        fontSize: 16,
        fontFamily: 'Arial'
      });
    }, 100);

    // Initialize selected color
    this.selectedColor = '#ef4444';

    // Setup toolbar buttons
    const toolButtons = toolbar.querySelectorAll('.tool-btn');
    toolButtons.forEach(btn => {
      btn.onclick = () => {
        // Update button styles
        toolButtons.forEach(b => {
          b.style.background = 'white';
          b.style.border = '1px solid #e5e7eb';
          const svg = b.querySelector('svg');
          if (svg) svg.setAttribute('stroke', '#6b7280');
        });
        btn.style.background = '#3b82f6';
        btn.style.border = '1px solid #3b82f6';
        const svg = btn.querySelector('svg');
        if (svg) svg.setAttribute('stroke', 'white');

        this.currentTool = btn.dataset.tool;
        if (this.markMyImage) {
          this.markMyImage.setTool(btn.dataset.tool);
        }
      };
    });

    // Setup color buttons
    const colorButtons = toolbar.querySelectorAll('.color-btn');
    colorButtons.forEach(btn => {
      btn.onclick = () => {
        colorButtons.forEach(b => b.style.border = '2px solid #fff');
        btn.style.border = '3px solid #3b82f6';
        this.selectedColor = btn.dataset.color;
        if (this.markMyImage) {
          this.markMyImage.setColor(btn.dataset.color);
        }
      };
    });

    // Setup stroke width selector
    document.getElementById('bugsnap-stroke-width').onchange = (e) => {
      if (this.markMyImage) {
        this.markMyImage.setStrokeWidth(parseInt(e.target.value));
      }
    };

    // Setup undo/redo buttons
    document.getElementById('bugsnap-undo').onclick = () => {
      if (this.markMyImage) {
        this.markMyImage.undo();
      }
    };

    document.getElementById('bugsnap-redo').onclick = () => {
      if (this.markMyImage) {
        this.markMyImage.redo();
      }
    };

    // Setup delete button
    document.getElementById('bugsnap-delete-annotation').onclick = () => {
      if (this.markMyImage) {
        this.markMyImage.deleteSelectedAnnotation();
      }
    };

    // Setup record button
    document.getElementById('bugsnap-record-btn').onclick = () => {
      if (this.mediaRecorder && this.mediaRecorder.state === 'recording') {
        this.stopRecording();
      } else {
        this.startRecording();
      }
    };

    // Setup save/cancel buttons
    document.getElementById('bugsnap-cancel-annotation').onclick = () => {
      document.body.style.overflow = ''; // Re-enable scrolling
      modal.remove();
      this.reset();
      this.startTagging();
    };

    document.getElementById('bugsnap-save-annotation').onclick = () => {
      // Keep the annotation modal open, just show task form
      this.showTaskForm();
    };

    this.currentTool = 'rectangle';
  }



  async startRecording() {
    try {
      const stream = await navigator.mediaDevices.getDisplayMedia({
        video: { mediaSource: 'tab', frameRate: 30 },
        audio: false,
      });

      this.recordedChunks = [];
      const mimeType = MediaRecorder.isTypeSupported('video/webm;codecs=vp9')
        ? 'video/webm;codecs=vp9'
        : 'video/webm';
      this.mediaRecorder = new MediaRecorder(stream, { mimeType });

      this.mediaRecorder.ondataavailable = (e) => {
        if (e.data.size > 0) this.recordedChunks.push(e.data);
      };

      this.mediaRecorder.onstop = () => {
        this.recording = new Blob(this.recordedChunks, { type: 'video/webm' });
        stream.getTracks().forEach((t) => t.stop());
        this.updateRecordButton(false);
        clearInterval(this.recordingTimerInterval);
      };

      // If user stops sharing via browser UI, handle gracefully
      stream.getVideoTracks()[0].onended = () => {
        if (this.mediaRecorder && this.mediaRecorder.state === 'recording') {
          this.mediaRecorder.stop();
        }
      };

      this.mediaRecorder.start(1000); // Collect data every second
      this.recordingStartTime = Date.now();
      this.updateRecordButton(true);

      // Update timer display
      this.recordingTimerInterval = setInterval(() => {
        const elapsed = Math.floor((Date.now() - this.recordingStartTime) / 1000);
        const mins = String(Math.floor(elapsed / 60)).padStart(2, '0');
        const secs = String(elapsed % 60).padStart(2, '0');
        const timerEl = document.getElementById('bugsnap-record-timer');
        if (timerEl) timerEl.textContent = `${mins}:${secs}`;
      }, 1000);
    } catch (err) {
      // User cancelled the picker or permission denied
      console.log('Recording cancelled or failed:', err.message);
    }
  }

  stopRecording() {
    if (this.mediaRecorder && this.mediaRecorder.state === 'recording') {
      this.mediaRecorder.stop();
    }
  }

  updateRecordButton(isRecording) {
    const btn = document.getElementById('bugsnap-record-btn');
    if (!btn) return;

    // Clear existing children
    while (btn.firstChild) btn.removeChild(btn.firstChild);

    if (isRecording) {
      btn.style.background = '#fef2f2';
      btn.style.borderColor = '#ef4444';
      btn.style.color = '#ef4444';

      // Stop icon (square)
      const svg = document.createElementNS('http://www.w3.org/2000/svg', 'svg');
      svg.setAttribute('width', '16');
      svg.setAttribute('height', '16');
      svg.setAttribute('viewBox', '0 0 24 24');
      svg.setAttribute('fill', 'none');
      svg.setAttribute('stroke', '#ef4444');
      svg.setAttribute('stroke-width', '2');
      const rect = document.createElementNS('http://www.w3.org/2000/svg', 'rect');
      rect.setAttribute('x', '6');
      rect.setAttribute('y', '6');
      rect.setAttribute('width', '12');
      rect.setAttribute('height', '12');
      rect.setAttribute('rx', '1');
      svg.appendChild(rect);
      btn.appendChild(svg);

      // Timer
      const timer = document.createElement('span');
      timer.id = 'bugsnap-record-timer';
      timer.style.fontVariantNumeric = 'tabular-nums';
      timer.textContent = '00:00';
      btn.appendChild(timer);

      // "Stop" label
      const label = document.createElement('span');
      label.textContent = 'Stop';
      btn.appendChild(label);
    } else {
      const hasRecording = !!this.recording;
      btn.style.background = hasRecording ? '#f0fdf4' : 'white';
      btn.style.borderColor = hasRecording ? '#22c55e' : '#e5e7eb';
      btn.style.color = hasRecording ? '#16a34a' : '#6b7280';

      const svg = document.createElementNS('http://www.w3.org/2000/svg', 'svg');
      svg.setAttribute('width', '16');
      svg.setAttribute('height', '16');
      svg.setAttribute('viewBox', '0 0 24 24');

      if (hasRecording) {
        // Checkmark icon
        svg.setAttribute('fill', 'none');
        svg.setAttribute('stroke', '#16a34a');
        svg.setAttribute('stroke-width', '2');
        const path1 = document.createElementNS('http://www.w3.org/2000/svg', 'path');
        path1.setAttribute('d', 'M22 11.08V12a10 10 0 1 1-5.93-9.14');
        svg.appendChild(path1);
        const path2 = document.createElementNS('http://www.w3.org/2000/svg', 'polyline');
        path2.setAttribute('points', '22 4 12 14.01 9 11.01');
        svg.appendChild(path2);
      } else {
        // Red circle (record) icon
        svg.setAttribute('fill', '#ef4444');
        svg.setAttribute('stroke', 'none');
        const circle = document.createElementNS('http://www.w3.org/2000/svg', 'circle');
        circle.setAttribute('cx', '12');
        circle.setAttribute('cy', '12');
        circle.setAttribute('r', '7');
        svg.appendChild(circle);
      }

      btn.appendChild(svg);
      const label = document.createElement('span');
      label.textContent = hasRecording ? 'Recorded' : 'Record';
      btn.appendChild(label);
    }
  }

  blobToBase64(blob) {
    return new Promise((resolve, reject) => {
      const reader = new FileReader();
      reader.onloadend = () => {
        // Remove the data URL prefix to get raw base64
        const base64 = reader.result.split(',')[1];
        resolve(base64);
      };
      reader.onerror = reject;
      reader.readAsDataURL(blob);
    });
  }

  async showTaskForm() {
    // First, fetch the next task number
    let nextTaskNumber = 1;
    try {
      chrome.storage.local.get(['token'], async (result) => {
        const token = result.token;

        // Send message to background script to fetch next task number (avoids CORS issues)
        chrome.runtime.sendMessage({ action: 'fetchNextTaskNumber', token, projectId: this.project.id }, (response) => {
          if (chrome.runtime.lastError) {
            this.showTaskFormWithNumber(nextTaskNumber);
            return;
          }

          if (response.error) {
            this.showTaskFormWithNumber(nextTaskNumber);
            return;
          }

          nextTaskNumber = response.nextTaskNumber;
          this.showTaskFormWithNumber(nextTaskNumber);
        });
      });
    } catch (error) {
      // Show form with default number if fetch fails
      this.showTaskFormWithNumber(nextTaskNumber);
    }
  }

  showTaskFormWithNumber(taskNumber) {
    const modal = document.createElement('div');
    modal.id = 'bugsnap-task-modal';
    modal.style.cssText = `
      position: fixed;
      top: 0;
      left: 0;
      width: 100%;
      height: 100%;
      background: rgba(0, 0, 0, 0.5);
      z-index: 9999999;
      display: flex;
      align-items: center;
      justify-content: center;
      padding: 20px;
    `;

    const form = document.createElement('div');
    form.style.cssText = `
      background: white;
      border-radius: 8px;
      width: 100%;
      max-width: 600px;
      box-shadow: 0 20px 25px -5px rgba(0, 0, 0, 0.1);
    `;

    // Build form using safe DOM methods — taskNumber is an integer, not user input
    const header = document.createElement('div');
    header.style.cssText = 'padding: 16px 20px; border-bottom: 1px solid #e5e7eb; display: flex; align-items: center; justify-content: space-between;';
    const h2 = document.createElement('h2');
    h2.style.cssText = 'margin: 0; font-size: 15px; font-weight: 400; color: #9ca3af;';
    h2.textContent = 'Task #' + taskNumber;
    const closeBtn = document.createElement('button');
    closeBtn.id = 'bugsnap-close-task';
    closeBtn.style.cssText = 'background: none; border: none; color: #9ca3af; font-size: 24px; cursor: pointer; padding: 0; line-height: 1;';
    closeBtn.textContent = '\u00D7';
    header.appendChild(h2);
    header.appendChild(closeBtn);

    const content = document.createElement('div');
    content.id = 'bugsnap-task-content';
    content.style.cssText = 'padding: 20px;';

    const titleWrap = document.createElement('div');
    titleWrap.style.cssText = 'margin-bottom: 12px;';
    const titleInput = document.createElement('input');
    titleInput.id = 'bugsnap-task-title';
    titleInput.type = 'text';
    titleInput.placeholder = 'Task title (e.g., Button not working)';
    titleInput.style.cssText = 'width: 100%; padding: 12px; border: 1px solid #d1d5db; border-radius: 6px; font-size: 14px; font-family: inherit; color: #374151; box-sizing: border-box;';
    titleWrap.appendChild(titleInput);

    const descWrap = document.createElement('div');
    descWrap.style.cssText = 'margin-bottom: 12px;';
    const descArea = document.createElement('textarea');
    descArea.id = 'bugsnap-task-description';
    descArea.rows = 5;
    descArea.placeholder = 'Add description';
    descArea.style.cssText = 'width: 100%; padding: 12px; border: 1px solid #d1d5db; border-radius: 6px; font-size: 14px; resize: vertical; font-family: inherit; color: #374151; box-sizing: border-box; min-height: 100px;';
    descWrap.appendChild(descArea);

    const submitBtn = document.createElement('button');
    submitBtn.id = 'bugsnap-submit-task';
    submitBtn.textContent = 'Create task';
    submitBtn.style.cssText = 'width: 100%; padding: 12px; background: #3b82f6; color: white; border: none; border-radius: 6px; font-size: 14px; font-weight: 500; cursor: pointer; transition: background 0.2s;';
    submitBtn.onmouseover = () => { submitBtn.style.background = '#2563eb'; };
    submitBtn.onmouseout = () => { submitBtn.style.background = '#3b82f6'; };

    content.appendChild(titleWrap);
    content.appendChild(descWrap);
    content.appendChild(submitBtn);

    form.appendChild(header);
    form.appendChild(content);
    modal.appendChild(form);
    document.body.appendChild(modal);

    // Setup buttons
    closeBtn.onclick = () => {
      modal.remove();
      this.reset();
    };

    submitBtn.onclick = () => {
      const title = titleInput.value;
      const description = descArea.value;
      this.submitTask(title, description);
    };
  }

  async submitTask(title, description) {
    const submitBtn = document.getElementById('bugsnap-submit-task');
    submitBtn.textContent = 'Creating...';
    submitBtn.disabled = true;

    try {
      // Get token from Chrome storage
      chrome.storage.local.get(['token'], async (result) => {
        const token = result.token;
        const rect = this.selectedElement.getBoundingClientRect();

        // Get annotations from MarkMyImage library
        const annotations = this.markMyImage ? this.markMyImage.getAnnotations() : [];

        // Capture annotation canvas size for coordinate scaling in the frontend
        const screenshotImg = document.getElementById('bugsnap-screenshot');
        const annotationCanvasSize = screenshotImg
          ? { width: screenshotImg.clientWidth, height: screenshotImg.clientHeight }
          : null;

        const payload = {
          projectId: this.project.id,
          title: title || 'Untitled', // User's title, API will prepend task number
          description: description,
          url: window.location.href,
          screenshotUrl: this.screenshot,
          environmentData: {
            browser: navigator.userAgent,
            os: navigator.platform,
            timestamp: new Date().toISOString(),
            screenResolution: `${screen.width}x${screen.height}`,
            viewportSize: `${window.innerWidth}x${window.innerHeight}`,
            deviceType: /Mobi|Android/i.test(navigator.userAgent) ? 'mobile' : (window.innerWidth <= 1024 ? 'tablet' : 'desktop'),
            reporterEmail: this.userEmail || undefined,
            annotationCanvasSize: annotationCanvasSize,
            selectedElement: {
              tagName: this.selectedElement.tagName,
              innerText: this.selectedElement.innerText?.substring(0, 100),
              cssSelector: this.getCssSelector(this.selectedElement),
              clickX: this.clickX,
              clickY: this.clickY,
              devicePixelRatio: window.devicePixelRatio || 1,
              boundingClientRect: {
                x: rect.left,
                y: rect.top,
                width: rect.width,
                height: rect.height
              }
            }
          },
          annotations: annotations || []
        };

        // Send message to background script to create task (avoids CORS issues)
        chrome.runtime.sendMessage({ action: 'createTask', token, payload }, (response) => {
          if (chrome.runtime.lastError) {
            alert('Failed to create task: ' + chrome.runtime.lastError.message);
            submitBtn.textContent = 'Create Task';
            submitBtn.disabled = false;
            return;
          }

          if (response.error) {
            alert('Failed to create task: ' + response.error);
            submitBtn.textContent = 'Create Task';
            submitBtn.disabled = false;
            return;
          }

          // Upload screen recording as attachment if one was captured
          if (this.recording && response.task && response.task.id) {
            submitBtn.textContent = 'Uploading recording...';
            this.blobToBase64(this.recording).then((base64Data) => {
              chrome.runtime.sendMessage({
                action: 'uploadRecording',
                token,
                issueId: response.task.id,
                recordingBase64: base64Data,
              }, (uploadResponse) => {
                if (uploadResponse && uploadResponse.error) {
                  console.warn('Recording upload failed:', uploadResponse.error);
                }
                this.showSuccess();
              });
            });
          } else {
            this.showSuccess();
          }
        });
      });
    } catch (error) {
      alert('Failed to create task: ' + error.message);
      submitBtn.textContent = 'Create Task';
      submitBtn.disabled = false;
    }
  }

  showSuccess() {
    // Close task form modal
    const taskModal = document.getElementById('bugsnap-task-modal');
    if (taskModal) taskModal.remove();

    // Close annotation modal
    const annotationModal = document.getElementById('bugsnap-annotation-modal');
    if (annotationModal) {
      document.body.style.overflow = ''; // Re-enable scrolling
      annotationModal.remove();
    }

    const success = document.createElement('div');
    success.style.cssText = `
      position: fixed;
      top: 50%;
      left: 50%;
      transform: translate(-50%, -50%);
      background: #10b981;
      color: white;
      padding: 16px 24px;
      border-radius: 8px;
      box-shadow: 0 10px 25px -5px rgba(0, 0, 0, 0.1);
      z-index: 9999999;
      font-size: 16px;
      font-weight: 500;
    `;
    success.textContent = '\u2713 Task created successfully!';
    document.body.appendChild(success);

    // Switch back to tasks-only mode and re-show tasks button
    this.mode = 'tasks-only';
    if (this.tasksButton) this.tasksButton.style.display = '';

    // Invalidate cached tasks so next drawer open re-fetches
    this.tasks = [];
    this.currentPageTasks = [];

    setTimeout(() => {
      success.remove();
      this.reset();
    }, 2000);
  }

  reset() {
    // Remove highlight from selected element
    if (this.selectedElement) {
      this.selectedElement.style.outline = '';
      this.selectedElement.style.outlineOffset = '';
    }
    this.selectedElement = null;
    this.screenshot = null;
    this.annotations = [];
    this.selectedAnnotationIndex = null;
    this.isTagging = false;

    // Clean up recording state
    if (this.mediaRecorder && this.mediaRecorder.state === 'recording') {
      this.mediaRecorder.stop();
    }
    if (this.mediaRecorder && this.mediaRecorder.stream) {
      this.mediaRecorder.stream.getTracks().forEach(track => track.stop());
    }
    this.mediaRecorder = null;
    this.recording = null;
    this.recordedChunks = [];
    if (this.recordingTimerInterval) {
      clearInterval(this.recordingTimerInterval);
      this.recordingTimerInterval = null;
    }
    this.recordingStartTime = null;

    // Remove pin marker
    if (this.pinMarker) {
      this.pinMarker.remove();
      this.pinMarker = null;
    }

    // Clean up MarkMyImage instance
    if (this.markMyImage) {
      this.markMyImage.destroy();
      this.markMyImage = null;
    }
  }

  // =============================================
  // Tasks Drawer Feature
  // =============================================

  createTasksButton() {
    const btn = document.createElement('button');
    btn.id = 'bugsnap-tasks-button';
    btn.setAttribute('aria-label', 'Toggle tasks drawer');
    btn.setAttribute('aria-expanded', 'false');
    btn.setAttribute('tabindex', '0');
    btn.style.cssText = `
      position: fixed;
      top: 16px;
      right: 16px;
      z-index: 9999989;
      width: 40px;
      height: 40px;
      background: #3b82f6;
      border: none;
      border-radius: 8px;
      cursor: pointer;
      display: flex;
      align-items: center;
      justify-content: center;
      box-shadow: 0 2px 8px rgba(59,130,246,0.4);
      transition: background 0.2s, transform 0.15s;
      padding: 0;
    `;

    // Build icon using safe DOM methods
    const svg = document.createElementNS('http://www.w3.org/2000/svg', 'svg');
    svg.setAttribute('width', '20');
    svg.setAttribute('height', '20');
    svg.setAttribute('viewBox', '0 0 24 24');
    svg.setAttribute('fill', 'none');
    svg.setAttribute('stroke', 'white');
    svg.setAttribute('stroke-width', '2');
    svg.setAttribute('stroke-linecap', 'round');
    svg.setAttribute('stroke-linejoin', 'round');

    const paths = [
      'M16 4h2a2 2 0 0 1 2 2v14a2 2 0 0 1-2 2H6a2 2 0 0 1-2-2V6a2 2 0 0 1 2-2h2',
      'M9 12h6',
      'M9 16h6'
    ];
    for (const d of paths) {
      const path = document.createElementNS('http://www.w3.org/2000/svg', 'path');
      path.setAttribute('d', d);
      svg.appendChild(path);
    }
    const rect = document.createElementNS('http://www.w3.org/2000/svg', 'rect');
    rect.setAttribute('width', '8');
    rect.setAttribute('height', '4');
    rect.setAttribute('x', '8');
    rect.setAttribute('y', '2');
    rect.setAttribute('rx', '1');
    rect.setAttribute('ry', '1');
    svg.appendChild(rect);

    btn.appendChild(svg);

    btn.onmouseenter = () => { btn.style.background = '#2563eb'; btn.style.transform = 'scale(1.05)'; };
    btn.onmouseleave = () => { btn.style.background = '#3b82f6'; btn.style.transform = 'scale(1)'; };
    btn.onclick = () => this.toggleTasksDrawer();

    document.body.appendChild(btn);
    this.tasksButton = btn;
  }

  updateTasksBadge() {
    if (!this.tasksButton) return;
    // Remove existing badge
    const existing = this.tasksButton.querySelector('.bugsnap-tasks-badge');
    if (existing) existing.remove();

    const count = this.currentPageTasks.length;
    if (count === 0) return;

    const badge = document.createElement('span');
    badge.className = 'bugsnap-tasks-badge';
    badge.textContent = count > 99 ? '99+' : count;
    badge.style.cssText = `
      position: absolute;
      top: -4px;
      right: -4px;
      background: #ef4444;
      color: white;
      font-size: 10px;
      font-weight: 600;
      min-width: 16px;
      height: 16px;
      border-radius: 8px;
      display: flex;
      align-items: center;
      justify-content: center;
      padding: 0 4px;
      line-height: 1;
    `;
    this.tasksButton.appendChild(badge);
  }

  toggleTasksDrawer() {
    if (this.tasksDrawerOpen) {
      this.closeTasksDrawer();
    } else {
      this.openTasksDrawer();
    }
  }

  openTasksDrawer() {
    if (this.tasksDrawerOpen) return;
    this.tasksDrawerOpen = true;

    if (this.tasksButton) {
      this.tasksButton.setAttribute('aria-expanded', 'true');
    }

    this.createDrawerDOM();
    this.attachDrawerKeyboardHandler();

    // Fetch tasks (always re-fetch on open to get latest)
    this.fetchTasks();

    // Animate in
    requestAnimationFrame(() => {
      if (this.tasksDrawer) {
        this.tasksDrawer.style.transform = 'translateX(0)';
      }
      if (this.tasksDrawerBackdrop) {
        this.tasksDrawerBackdrop.style.opacity = '1';
      }
    });
  }

  closeTasksDrawer() {
    if (!this.tasksDrawerOpen) return;
    this.tasksDrawerOpen = false;

    if (this.tasksButton) {
      this.tasksButton.setAttribute('aria-expanded', 'false');
    }

    // Animate out
    if (this.tasksDrawer) {
      this.tasksDrawer.style.transform = 'translateX(100%)';
    }
    if (this.tasksDrawerBackdrop) {
      this.tasksDrawerBackdrop.style.opacity = '0';
    }

    // Remove DOM after animation
    setTimeout(() => {
      if (this.tasksDrawer) {
        this.tasksDrawer.remove();
        this.tasksDrawer = null;
      }
      if (this.tasksDrawerBackdrop) {
        this.tasksDrawerBackdrop.remove();
        this.tasksDrawerBackdrop = null;
      }
    }, 250);

    // Remove pins and clear selection
    this.removeTaskPins();
    this.selectedTaskId = null;

    // Remove keyboard handler
    if (this.tasksKeydownHandler) {
      document.removeEventListener('keydown', this.tasksKeydownHandler, true);
      this.tasksKeydownHandler = null;
    }

    // Restore focus
    if (this.tasksButton) this.tasksButton.focus();
  }

  createDrawerDOM() {
    // Backdrop
    const backdrop = document.createElement('div');
    backdrop.id = 'bugsnap-tasks-backdrop';
    backdrop.style.cssText = `
      position: fixed;
      top: 0;
      left: 0;
      width: 100%;
      height: 100%;
      background: rgba(0, 0, 0, 0.3);
      z-index: 9999988;
      opacity: 0;
      transition: opacity 0.25s ease;
    `;
    backdrop.onclick = () => this.closeTasksDrawer();
    document.body.appendChild(backdrop);
    this.tasksDrawerBackdrop = backdrop;

    // Drawer panel
    const drawer = document.createElement('div');
    drawer.id = 'bugsnap-tasks-drawer';
    drawer.style.cssText = `
      position: fixed;
      top: 0;
      right: 0;
      width: 400px;
      max-width: 90vw;
      height: 100%;
      background: white;
      z-index: 9999989;
      display: flex;
      flex-direction: column;
      box-shadow: -4px 0 20px rgba(0,0,0,0.15);
      transform: translateX(100%);
      transition: transform 0.25s ease;
      font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, sans-serif;
    `;

    // Header — built with safe DOM methods
    const header = document.createElement('div');
    header.style.cssText = 'padding: 16px; border-bottom: 1px solid #e5e7eb; display: flex; align-items: center; gap: 8px; flex-shrink: 0;';

    const titleSpan = document.createElement('span');
    titleSpan.style.cssText = 'font-size: 16px; font-weight: 600; color: #111827;';
    titleSpan.textContent = 'Tasks';

    const countBadge = document.createElement('span');
    countBadge.id = 'bugsnap-drawer-count';
    countBadge.style.cssText = 'background: #e5e7eb; color: #6b7280; font-size: 11px; font-weight: 600; padding: 2px 6px; border-radius: 10px;';
    countBadge.textContent = '0';

    const spacer = document.createElement('div');
    spacer.style.cssText = 'flex: 1;';

    const filterSelect = document.createElement('select');
    filterSelect.id = 'bugsnap-tasks-filter';
    filterSelect.style.cssText = 'padding: 4px 8px; border: 1px solid #e5e7eb; border-radius: 4px; font-size: 12px; color: #374151; background: white; cursor: pointer;';
    const optPage = document.createElement('option');
    optPage.value = 'page';
    optPage.textContent = 'This Page';
    const optAll = document.createElement('option');
    optAll.value = 'all';
    optAll.textContent = 'All Tasks';
    filterSelect.appendChild(optPage);
    filterSelect.appendChild(optAll);
    filterSelect.value = this.tasksFilter;

    const closeButton = document.createElement('button');
    closeButton.id = 'bugsnap-drawer-close';
    closeButton.setAttribute('aria-label', 'Close tasks drawer');
    closeButton.style.cssText = 'background: none; border: none; cursor: pointer; padding: 4px; display: flex; align-items: center; justify-content: center; border-radius: 4px; color: #6b7280;';
    const closeSvg = document.createElementNS('http://www.w3.org/2000/svg', 'svg');
    closeSvg.setAttribute('width', '18');
    closeSvg.setAttribute('height', '18');
    closeSvg.setAttribute('viewBox', '0 0 24 24');
    closeSvg.setAttribute('fill', 'none');
    closeSvg.setAttribute('stroke', 'currentColor');
    closeSvg.setAttribute('stroke-width', '2');
    const p1 = document.createElementNS('http://www.w3.org/2000/svg', 'path');
    p1.setAttribute('d', 'M18 6 6 18');
    const p2 = document.createElementNS('http://www.w3.org/2000/svg', 'path');
    p2.setAttribute('d', 'm6 6 12 12');
    closeSvg.appendChild(p1);
    closeSvg.appendChild(p2);
    closeButton.appendChild(closeSvg);

    header.appendChild(titleSpan);
    header.appendChild(countBadge);
    header.appendChild(spacer);
    header.appendChild(filterSelect);
    header.appendChild(closeButton);

    // Task list area
    const taskList = document.createElement('div');
    taskList.id = 'bugsnap-task-list';
    taskList.setAttribute('role', 'listbox');
    taskList.style.cssText = 'flex: 1; overflow-y: auto; padding: 8px 0;';

    // Detail panel (collapsed by default)
    const detailPanel = document.createElement('div');
    detailPanel.id = 'bugsnap-task-detail';
    detailPanel.style.cssText = 'border-top: 1px solid #e5e7eb; max-height: 0; overflow: hidden; transition: max-height 0.25s ease; flex-shrink: 0;';

    drawer.appendChild(header);
    drawer.appendChild(taskList);
    drawer.appendChild(detailPanel);
    document.body.appendChild(drawer);
    this.tasksDrawer = drawer;

    // Setup event handlers
    closeButton.onclick = () => this.closeTasksDrawer();
    filterSelect.onchange = (e) => this.handleTasksFilterChange(e);
  }

  fetchTasks() {
    this.tasksLoading = true;
    this.renderLoadingState();

    chrome.storage.local.get(['token'], (result) => {
      const token = result.token;
      if (!token) {
        this.tasksLoading = false;
        this.renderEmptyState('Not logged in. Please log in to BugSnap.');
        return;
      }

      chrome.runtime.sendMessage({
        action: 'fetchProjectIssues',
        token,
        projectId: this.project.id
      }, (response) => {
        this.tasksLoading = false;

        if (chrome.runtime.lastError) {
          this.renderEmptyState('Failed to load tasks.');
          return;
        }

        if (response && response.error) {
          this.renderEmptyState('Failed to load tasks.');
          return;
        }

        this.tasks = (response && response.issues) || [];
        this.filterTasksForCurrentPage();
        this.renderTaskList();
        this.renderTaskPins();
        this.updateTasksBadge();
      });
    });
  }

  filterTasksForCurrentPage() {
    const currentUrl = this.normalizeUrl(window.location.href);
    this.currentPageTasks = this.tasks.filter(task => {
      return this.normalizeUrl(task.url) === currentUrl;
    });
  }

  renderLoadingState() {
    const list = document.getElementById('bugsnap-task-list');
    if (!list) return;
    const div = document.createElement('div');
    div.style.cssText = 'display: flex; align-items: center; justify-content: center; padding: 40px 16px; color: #9ca3af; font-size: 13px;';
    div.textContent = 'Loading tasks...';
    list.replaceChildren(div);
  }

  renderEmptyState(message) {
    const list = document.getElementById('bugsnap-task-list');
    if (!list) return;

    const wrapper = document.createElement('div');
    wrapper.style.cssText = 'display: flex; flex-direction: column; align-items: center; justify-content: center; padding: 40px 16px; color: #9ca3af; text-align: center;';

    const svg = document.createElementNS('http://www.w3.org/2000/svg', 'svg');
    svg.setAttribute('width', '40');
    svg.setAttribute('height', '40');
    svg.setAttribute('viewBox', '0 0 24 24');
    svg.setAttribute('fill', 'none');
    svg.setAttribute('stroke', '#d1d5db');
    svg.setAttribute('stroke-width', '1.5');
    svg.style.marginBottom = '12px';
    const ep1 = document.createElementNS('http://www.w3.org/2000/svg', 'path');
    ep1.setAttribute('d', 'M16 4h2a2 2 0 0 1 2 2v14a2 2 0 0 1-2 2H6a2 2 0 0 1-2-2V6a2 2 0 0 1 2-2h2');
    const erect = document.createElementNS('http://www.w3.org/2000/svg', 'rect');
    erect.setAttribute('width', '8');
    erect.setAttribute('height', '4');
    erect.setAttribute('x', '8');
    erect.setAttribute('y', '2');
    erect.setAttribute('rx', '1');
    erect.setAttribute('ry', '1');
    svg.appendChild(ep1);
    svg.appendChild(erect);

    const msgSpan = document.createElement('span');
    msgSpan.style.cssText = 'font-size: 13px;';
    msgSpan.textContent = message || 'No tasks found';

    wrapper.appendChild(svg);
    wrapper.appendChild(msgSpan);
    list.replaceChildren(wrapper);
  }

  getStatusColor(status) {
    const colors = {
      'open': '#eab308',
      'in_progress': '#3b82f6',
      'qa': '#a855f7',
      'resolved': '#22c55e',
      'closed': '#6b7280'
    };
    return colors[status] || '#6b7280';
  }

  getStatusLabel(status) {
    const labels = {
      'open': 'Open',
      'in_progress': 'In Progress',
      'qa': 'QA',
      'resolved': 'Resolved',
      'closed': 'Closed'
    };
    return labels[status] || status;
  }

  getTypeColor(type) {
    const colors = {
      'BUG': '#ef4444',
      'FEATURE': '#3b82f6',
      'IMPROVEMENT': '#8b5cf6',
      'TASK': '#6b7280'
    };
    return colors[type] || '#6b7280';
  }

  renderTaskList() {
    const list = document.getElementById('bugsnap-task-list');
    if (!list) return;

    const tasks = this.tasksFilter === 'page' ? this.currentPageTasks : this.tasks;

    // Update count badge in header
    const countEl = document.getElementById('bugsnap-drawer-count');
    if (countEl) countEl.textContent = tasks.length;

    if (tasks.length === 0) {
      const msg = this.tasksFilter === 'page'
        ? 'No tasks for this page'
        : 'No tasks in this project';
      this.renderEmptyState(msg);
      return;
    }

    // Group tasks by status in order (DB stores lowercase)
    const statusOrder = ['open', 'in_progress', 'qa', 'resolved', 'closed'];
    const groups = {};
    for (const task of tasks) {
      const s = task.status || 'open';
      if (!groups[s]) groups[s] = [];
      groups[s].push(task);
    }

    // Build task list using safe DOM methods
    const fragment = document.createDocumentFragment();

    for (const status of statusOrder) {
      const group = groups[status];
      if (!group || group.length === 0) continue;

      const color = this.getStatusColor(status);
      const label = this.getStatusLabel(status);

      const groupDiv = document.createElement('div');
      groupDiv.className = 'bugsnap-task-group';
      groupDiv.dataset.status = status;

      // Group header
      const headerBtn = document.createElement('button');
      headerBtn.className = 'bugsnap-task-group-header';
      headerBtn.style.cssText = 'width: 100%; background: none; border: none; padding: 8px 16px; display: flex; align-items: center; gap: 8px; cursor: pointer; font-size: 11px; font-weight: 600; text-transform: uppercase; letter-spacing: 0.05em; color: #6b7280;';

      const statusDot = document.createElement('span');
      statusDot.style.cssText = `width: 8px; height: 8px; border-radius: 50%; background: ${color}; flex-shrink: 0;`;
      const labelSpan = document.createElement('span');
      labelSpan.textContent = label;
      const countSpan = document.createElement('span');
      countSpan.style.cssText = 'color: #9ca3af; font-weight: 400;';
      countSpan.textContent = group.length;
      const chevronSvg = document.createElementNS('http://www.w3.org/2000/svg', 'svg');
      chevronSvg.className.baseVal = 'bugsnap-group-chevron';
      chevronSvg.setAttribute('width', '14');
      chevronSvg.setAttribute('height', '14');
      chevronSvg.setAttribute('viewBox', '0 0 24 24');
      chevronSvg.setAttribute('fill', 'none');
      chevronSvg.setAttribute('stroke', '#9ca3af');
      chevronSvg.setAttribute('stroke-width', '2');
      chevronSvg.style.cssText = 'margin-left: auto; transition: transform 0.15s;';
      const chevPath = document.createElementNS('http://www.w3.org/2000/svg', 'path');
      chevPath.setAttribute('d', 'm6 9 6 6 6-6');
      chevronSvg.appendChild(chevPath);

      headerBtn.appendChild(statusDot);
      headerBtn.appendChild(labelSpan);
      headerBtn.appendChild(countSpan);
      headerBtn.appendChild(chevronSvg);

      const itemsDiv = document.createElement('div');
      itemsDiv.className = 'bugsnap-task-group-items';

      // Task items
      for (const task of group) {
        const isSelected = task.id === this.selectedTaskId;
        const typeColor = this.getTypeColor(task.type);
        const assigneeName = task.assignedTo ? (task.assignedTo.name || task.assignedTo.email) : '';
        const commentCount = task._count ? task._count.comments : 0;

        const item = document.createElement('div');
        item.className = 'bugsnap-task-item';
        item.dataset.taskId = task.id;
        item.setAttribute('role', 'option');
        item.setAttribute('aria-selected', isSelected ? 'true' : 'false');
        item.setAttribute('tabindex', '0');
        item.style.cssText = `
          padding: 10px 16px;
          cursor: pointer;
          display: flex;
          align-items: flex-start;
          gap: 10px;
          border-left: 3px solid ${isSelected ? '#3b82f6' : 'transparent'};
          background: ${isSelected ? '#eff6ff' : 'transparent'};
          transition: background 0.1s, border-color 0.1s;
        `;

        const typeDot = document.createElement('span');
        typeDot.style.cssText = `width: 8px; height: 8px; border-radius: 50%; background: ${typeColor}; flex-shrink: 0; margin-top: 5px;`;

        const contentDiv = document.createElement('div');
        contentDiv.style.cssText = 'flex: 1; min-width: 0;';

        const titleDiv = document.createElement('div');
        titleDiv.style.cssText = 'font-size: 13px; color: #111827; font-weight: 500; white-space: nowrap; overflow: hidden; text-overflow: ellipsis;';
        titleDiv.textContent = task.title;

        const metaDiv = document.createElement('div');
        metaDiv.style.cssText = 'display: flex; align-items: center; gap: 8px; margin-top: 4px; font-size: 11px; color: #9ca3af;';
        if (assigneeName) {
          const nameSpan = document.createElement('span');
          nameSpan.textContent = assigneeName;
          metaDiv.appendChild(nameSpan);
        }
        if (commentCount > 0) {
          const commentSpan = document.createElement('span');
          commentSpan.style.cssText = 'display: flex; align-items: center; gap: 2px;';
          const commentSvg = document.createElementNS('http://www.w3.org/2000/svg', 'svg');
          commentSvg.setAttribute('width', '12');
          commentSvg.setAttribute('height', '12');
          commentSvg.setAttribute('viewBox', '0 0 24 24');
          commentSvg.setAttribute('fill', 'none');
          commentSvg.setAttribute('stroke', 'currentColor');
          commentSvg.setAttribute('stroke-width', '2');
          const commentPath = document.createElementNS('http://www.w3.org/2000/svg', 'path');
          commentPath.setAttribute('d', 'M21 15a2 2 0 0 1-2 2H7l-4 4V5a2 2 0 0 1 2-2h14a2 2 0 0 1 2 2z');
          commentSvg.appendChild(commentPath);
          commentSpan.appendChild(commentSvg);
          commentSpan.appendChild(document.createTextNode(commentCount));
          metaDiv.appendChild(commentSpan);
        }

        contentDiv.appendChild(titleDiv);
        contentDiv.appendChild(metaDiv);

        const statusBadge = document.createElement('span');
        statusBadge.style.cssText = `font-size: 10px; font-weight: 500; padding: 2px 6px; border-radius: 4px; background: ${color}20; color: ${color}; white-space: nowrap; flex-shrink: 0;`;
        statusBadge.textContent = label;

        item.appendChild(typeDot);
        item.appendChild(contentDiv);
        item.appendChild(statusBadge);

        // Hover handlers
        item.onmouseenter = () => { if (item.dataset.taskId !== this.selectedTaskId) item.style.background = '#f9fafb'; };
        item.onmouseleave = () => { if (item.dataset.taskId !== this.selectedTaskId) item.style.background = 'transparent'; };
        item.onclick = () => this.selectTask(item.dataset.taskId);

        itemsDiv.appendChild(item);
      }

      // Collapse/expand handler
      headerBtn.onclick = () => {
        if (itemsDiv.style.display === 'none') {
          itemsDiv.style.display = '';
          chevronSvg.style.transform = '';
        } else {
          itemsDiv.style.display = 'none';
          chevronSvg.style.transform = 'rotate(-90deg)';
        }
      };

      groupDiv.appendChild(headerBtn);
      groupDiv.appendChild(itemsDiv);
      fragment.appendChild(groupDiv);
    }

    list.replaceChildren(fragment);
  }

  renderTaskDetail(taskId) {
    const detailPanel = document.getElementById('bugsnap-task-detail');
    if (!detailPanel) return;

    const task = this.tasks.find(t => t.id === taskId);
    if (!task) {
      detailPanel.style.maxHeight = '0';
      return;
    }

    const statusColor = this.getStatusColor(task.status);
    const statusLabel = this.getStatusLabel(task.status);
    const typeColor = this.getTypeColor(task.type);
    const typeLabel = task.type || 'TASK';

    // Build detail using safe DOM methods
    const container = document.createElement('div');
    container.style.cssText = 'padding: 16px;';

    // Status + type badges row
    const badgeRow = document.createElement('div');
    badgeRow.style.cssText = 'display: flex; align-items: center; gap: 8px; margin-bottom: 12px;';

    const sBadge = document.createElement('span');
    sBadge.style.cssText = `font-size: 10px; font-weight: 600; padding: 2px 8px; border-radius: 4px; background: ${statusColor}20; color: ${statusColor}; text-transform: uppercase;`;
    sBadge.textContent = statusLabel;

    const tBadge = document.createElement('span');
    tBadge.style.cssText = `font-size: 10px; font-weight: 500; padding: 2px 8px; border-radius: 4px; background: ${typeColor}15; color: ${typeColor}; text-transform: uppercase;`;
    tBadge.textContent = typeLabel;

    badgeRow.appendChild(sBadge);
    badgeRow.appendChild(tBadge);

    // Title
    const titleEl = document.createElement('div');
    titleEl.style.cssText = 'font-size: 14px; font-weight: 600; color: #111827; margin-bottom: 8px;';
    titleEl.textContent = task.title;

    // Description
    const descEl = document.createElement('div');
    descEl.style.cssText = 'font-size: 12px; color: #6b7280; line-height: 1.5; margin-bottom: 12px;';
    if (task.description) {
      descEl.textContent = task.description.substring(0, 200) + (task.description.length > 200 ? '...' : '');
    } else {
      descEl.style.color = '#9ca3af';
      descEl.textContent = 'No description';
    }

    // Meta row
    const metaRow = document.createElement('div');
    metaRow.style.cssText = 'display: flex; gap: 16px; font-size: 11px; color: #9ca3af; margin-bottom: 12px;';

    const createdBy = task.createdBy ? (task.createdBy.name || task.createdBy.email) : 'Unknown';
    const assignedTo = task.assignedTo ? (task.assignedTo.name || task.assignedTo.email) : 'Unassigned';
    const createdDate = task.createdAt ? new Date(task.createdAt).toLocaleDateString() : '';

    const bySpan = document.createElement('span');
    bySpan.textContent = 'By ' + createdBy;
    const assignSpan = document.createElement('span');
    assignSpan.textContent = 'Assigned: ' + assignedTo;
    metaRow.appendChild(bySpan);
    metaRow.appendChild(assignSpan);
    if (createdDate) {
      const dateSpan = document.createElement('span');
      dateSpan.textContent = createdDate;
      metaRow.appendChild(dateSpan);
    }

    container.appendChild(badgeRow);
    container.appendChild(titleEl);
    container.appendChild(descEl);
    container.appendChild(metaRow);

    // "Open in BugSnap" link
    const webUrl = typeof BUGSNAP_WEB_URL !== 'undefined' ? BUGSNAP_WEB_URL : '';
    if (webUrl) {
      const link = document.createElement('a');
      link.href = webUrl + '/projects/' + task.projectId + '/issues/' + task.id;
      link.target = '_blank';
      link.rel = 'noopener';
      link.style.cssText = 'font-size: 12px; color: #3b82f6; text-decoration: none; display: inline-flex; align-items: center; gap: 4px;';
      link.textContent = 'Open in BugSnap ';
      const linkSvg = document.createElementNS('http://www.w3.org/2000/svg', 'svg');
      linkSvg.setAttribute('width', '12');
      linkSvg.setAttribute('height', '12');
      linkSvg.setAttribute('viewBox', '0 0 24 24');
      linkSvg.setAttribute('fill', 'none');
      linkSvg.setAttribute('stroke', 'currentColor');
      linkSvg.setAttribute('stroke-width', '2');
      const lp1 = document.createElementNS('http://www.w3.org/2000/svg', 'path');
      lp1.setAttribute('d', 'M18 13v6a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2V8a2 2 0 0 1 2-2h6');
      const lp2 = document.createElementNS('http://www.w3.org/2000/svg', 'polyline');
      lp2.setAttribute('points', '15 3 21 3 21 9');
      const lp3 = document.createElementNS('http://www.w3.org/2000/svg', 'line');
      lp3.setAttribute('x1', '10');
      lp3.setAttribute('y1', '14');
      lp3.setAttribute('x2', '21');
      lp3.setAttribute('y2', '3');
      linkSvg.appendChild(lp1);
      linkSvg.appendChild(lp2);
      linkSvg.appendChild(lp3);
      link.appendChild(linkSvg);
      container.appendChild(link);
    }

    detailPanel.replaceChildren(container);
    detailPanel.style.maxHeight = '300px';
    detailPanel.style.overflowY = 'auto';
  }

  selectTask(taskId) {
    this.selectedTaskId = taskId;

    // If drawer is not open, open it first
    if (!this.tasksDrawerOpen) {
      this.openTasksDrawer();
      // Wait for drawer to open and tasks to load, then re-select
      setTimeout(() => this.selectTask(taskId), 500);
      return;
    }

    // Highlight the selected item in the list
    const list = document.getElementById('bugsnap-task-list');
    if (list) {
      list.querySelectorAll('.bugsnap-task-item').forEach(el => {
        const isThis = el.dataset.taskId === taskId;
        el.style.borderLeftColor = isThis ? '#3b82f6' : 'transparent';
        el.style.background = isThis ? '#eff6ff' : 'transparent';
        el.setAttribute('aria-selected', isThis ? 'true' : 'false');
      });

      // Scroll the selected item into view
      const selectedEl = list.querySelector('[data-task-id="' + taskId + '"]');
      if (selectedEl) {
        selectedEl.scrollIntoView({ block: 'nearest', behavior: 'smooth' });
      }
    }

    // Render detail panel
    this.renderTaskDetail(taskId);

    // Pulse the matching pin and scroll page to it
    this.pulseTaskPin(taskId);
    this.scrollToTaskPin(taskId);
  }

  // --- Task Pin Methods ---

  renderTaskPins() {
    this.removeTaskPins();

    const tasks = this.currentPageTasks;
    // Track positions to offset overlapping pins
    const positionMap = {};

    for (const task of tasks) {
      let envData = task.environmentData;
      if (typeof envData === 'string') {
        try { envData = JSON.parse(envData); } catch { continue; }
      }
      if (!envData || !envData.selectedElement || !envData.selectedElement.cssSelector) continue;

      const selector = envData.selectedElement.cssSelector;
      let targetEl;
      try {
        targetEl = document.querySelector(selector);
      } catch {
        continue;
      }
      if (!targetEl) continue;

      // Get element position in page coordinates
      const rect = targetEl.getBoundingClientRect();
      const pageX = rect.left + window.scrollX + rect.width / 2;
      const pageY = rect.top + window.scrollY;

      // Offset overlapping pins
      const posKey = Math.round(pageX) + '_' + Math.round(pageY);
      if (!positionMap[posKey]) positionMap[posKey] = 0;
      const offset = positionMap[posKey] * 28;
      positionMap[posKey]++;

      const pin = document.createElement('div');
      pin.className = 'bugsnap-task-pin';
      pin.dataset.taskId = task.id;
      pin.style.cssText = `
        position: absolute;
        top: ${pageY - 28}px;
        left: ${pageX - 8 + offset}px;
        width: 24px;
        height: 24px;
        background: #3b82f6;
        border-radius: 50% 50% 50% 0;
        transform: rotate(-45deg);
        z-index: 9999985;
        box-shadow: 0 2px 6px rgba(59,130,246,0.4);
        cursor: pointer;
        pointer-events: auto;
        transition: transform 0.2s, box-shadow 0.2s;
      `;

      const inner = document.createElement('div');
      inner.style.cssText = `
        width: 10px;
        height: 10px;
        background: white;
        border-radius: 50%;
        position: absolute;
        top: 50%;
        left: 50%;
        transform: translate(-50%, -50%);
      `;
      pin.appendChild(inner);

      pin.onclick = (e) => {
        e.stopPropagation();
        this.selectTask(task.id);
      };
      pin.onmouseenter = () => {
        pin.style.transform = 'rotate(-45deg) scale(1.2)';
        pin.style.boxShadow = '0 4px 12px rgba(59,130,246,0.5)';
      };
      pin.onmouseleave = () => {
        pin.style.transform = 'rotate(-45deg)';
        pin.style.boxShadow = '0 2px 6px rgba(59,130,246,0.4)';
      };

      document.body.appendChild(pin);
      this.taskPinMarkers.push(pin);
    }
  }

  removeTaskPins() {
    for (const pin of this.taskPinMarkers) {
      pin.remove();
    }
    this.taskPinMarkers = [];
  }

  pulseTaskPin(taskId) {
    const pin = this.taskPinMarkers.find(p => p.dataset.taskId === taskId);
    if (!pin) return;

    // Brief pulse animation
    pin.style.transition = 'transform 0.15s ease, box-shadow 0.15s ease';
    pin.style.transform = 'rotate(-45deg) scale(1.5)';
    pin.style.boxShadow = '0 0 16px rgba(59,130,246,0.7)';

    setTimeout(() => {
      pin.style.transform = 'rotate(-45deg) scale(1)';
      pin.style.boxShadow = '0 2px 6px rgba(59,130,246,0.4)';
    }, 400);
  }

  scrollToTaskPin(taskId) {
    const pin = this.taskPinMarkers.find(p => p.dataset.taskId === taskId);
    if (!pin) return;

    const pinTop = parseInt(pin.style.top, 10);
    const targetScroll = Math.max(0, pinTop - window.innerHeight / 3);
    window.scrollTo({ top: targetScroll, behavior: 'smooth' });
  }

  // --- Filter + Keyboard ---

  handleTasksFilterChange(e) {
    this.tasksFilter = e.target.value;
    this.renderTaskList();

    // Re-render pins only in "page" mode
    this.removeTaskPins();
    if (this.tasksFilter === 'page') {
      this.renderTaskPins();
    }
  }

  attachDrawerKeyboardHandler() {
    this.tasksKeydownHandler = (e) => {
      if (!this.tasksDrawerOpen) return;

      if (e.key === 'Escape') {
        e.preventDefault();
        e.stopPropagation();
        this.closeTasksDrawer();
        return;
      }

      if (e.key === 'ArrowDown' || e.key === 'ArrowUp') {
        e.preventDefault();
        const list = document.getElementById('bugsnap-task-list');
        if (!list) return;
        const items = Array.from(list.querySelectorAll('.bugsnap-task-item'));
        if (items.length === 0) return;

        const currentIdx = items.findIndex(el => el.dataset.taskId === this.selectedTaskId);
        let nextIdx;
        if (e.key === 'ArrowDown') {
          nextIdx = currentIdx < items.length - 1 ? currentIdx + 1 : 0;
        } else {
          nextIdx = currentIdx > 0 ? currentIdx - 1 : items.length - 1;
        }
        this.selectTask(items[nextIdx].dataset.taskId);
      }
    };

    document.addEventListener('keydown', this.tasksKeydownHandler, true);
  }

  // --- Destroy ---

  destroy() {
    // Close drawer if open
    if (this.tasksDrawerOpen) {
      // Remove immediately without animation
      if (this.tasksDrawer) { this.tasksDrawer.remove(); this.tasksDrawer = null; }
      if (this.tasksDrawerBackdrop) { this.tasksDrawerBackdrop.remove(); this.tasksDrawerBackdrop = null; }
      this.tasksDrawerOpen = false;
    }

    // Remove tasks button
    if (this.tasksButton) {
      this.tasksButton.remove();
      this.tasksButton = null;
    }

    // Remove task pins
    this.removeTaskPins();

    // Remove keyboard handler
    if (this.tasksKeydownHandler) {
      document.removeEventListener('keydown', this.tasksKeydownHandler, true);
      this.tasksKeydownHandler = null;
    }

    // Remove tagging listeners
    if (this.hoverHandler) {
      document.removeEventListener('mousemove', this.hoverHandler, true);
    }
    if (this.tagClickHandler) {
      document.removeEventListener('click', this.tagClickHandler, true);
    }

    // Remove all BugSnap DOM elements
    const ids = [
      'bugsnap-tagging-overlay',
      'bugsnap-annotation-modal',
      'bugsnap-task-modal'
    ];
    for (const id of ids) {
      const el = document.getElementById(id);
      if (el) el.remove();
    }

    // Remove pin marker
    if (this.pinMarker) {
      this.pinMarker.remove();
      this.pinMarker = null;
    }

    // Reset selected element highlight
    if (this.selectedElement) {
      this.selectedElement.style.outline = '';
      this.selectedElement.style.outlineOffset = '';
    }

    // Remove hovered element highlight
    if (this.hoveredElement) {
      this.hoveredElement.style.outline = '';
      this.hoveredElement.style.outlineOffset = '';
    }

    // Restore body state
    document.body.style.cursor = '';
    document.body.style.overflow = '';

    // Clean up recording
    if (this.mediaRecorder && this.mediaRecorder.state === 'recording') {
      this.mediaRecorder.stop();
    }
    if (this.mediaRecorder && this.mediaRecorder.stream) {
      this.mediaRecorder.stream.getTracks().forEach(track => track.stop());
    }
    if (this.recordingTimerInterval) {
      clearInterval(this.recordingTimerInterval);
    }

    // Clean up MarkMyImage
    if (this.markMyImage) {
      this.markMyImage.destroy();
      this.markMyImage = null;
    }
  }
}

// Export for use in content script
window.BugSnapUI = BugSnapUI;
