// Signal extension presence to the web app
document.documentElement.setAttribute('data-bugsnap-extension', 'true');

// Sync localStorage to Chrome storage periodically
function syncToChromeStorage() {
  try {
    const token = localStorage.getItem('bugsnap_token');
    const userEmail = localStorage.getItem('bugsnap_user_email');

    if (token || userEmail) {
      chrome.storage.local.set({
        token: token || null,
        userEmail: userEmail || null
      });
    }
  } catch (error) {
    // Extension context invalidated - this happens when extension is reloaded
  }
}

// Sync on load
syncToChromeStorage();

// Sync every 2 seconds to catch login changes
setInterval(syncToChromeStorage, 2000);

// Auto-initialize tasks-only mode if user is logged in and page matches a project
function autoInitTasksButton() {
  chrome.storage.local.get(['token'], (result) => {
    if (!result.token || window.BugSnapUIInstance) return;

    // Fetch projects to find a match for the current domain
    chrome.runtime.sendMessage({ action: 'fetchProjects', token: result.token }, (response) => {
      if (chrome.runtime.lastError || !response || response.error) return;

      const currentDomain = window.location.hostname;
      const matchingProject = (response.projects || []).find(project => {
        if (!project.websiteUrl) return false;
        try { return new URL(project.websiteUrl).hostname === currentDomain; }
        catch { return false; }
      });

      if (matchingProject && !window.BugSnapUIInstance && window.BugSnapUI) {
        window.BugSnapUIInstance = new window.BugSnapUI(matchingProject, 'tasks-only');
      }
    });
  });
}

// Run after page is ready
if (document.readyState === 'loading') {
  document.addEventListener('DOMContentLoaded', autoInitTasksButton);
} else {
  autoInitTasksButton();
}

// Load BugSnap UI in full mode (tagging + tasks)
function loadBugSnapUI(project) {
  if (window.BugSnapUIInstance) {
    // Already in tasks-only mode — upgrade to full mode
    if (window.BugSnapUIInstance.mode === 'tasks-only') {
      window.BugSnapUIInstance.enableTagging();
    }
    return;
  }

  if (window.BugSnapUI) {
    window.BugSnapUIInstance = new window.BugSnapUI(project);
  }
}

// Disable tagging but keep tasks button
function disableBugSnapUI() {
  if (window.BugSnapUIInstance) {
    if (window.BugSnapUIInstance.mode === 'full') {
      // Downgrade to tasks-only: stop tagging, keep tasks button
      window.BugSnapUIInstance.disableTagging();
    } else {
      // Already tasks-only, nothing to disable
    }
  }
  // Clean up overlay and cursor (safety net)
  const overlay = document.getElementById('bugsnap-overlay');
  if (overlay) overlay.remove();
  document.body.style.cursor = '';
}

// Listen for messages from popup
chrome.runtime.onMessage.addListener((message, sender, sendResponse) => {
  if (message.action === 'toggleBugSnap') {
    if (message.enabled) {
      loadBugSnapUI(message.project);
    } else {
      disableBugSnapUI();
    }
    sendResponse({ success: true });
  } else if (message.action === 'getBugSnapState') {
    sendResponse({
      enabled: !!(window.BugSnapUIInstance && window.BugSnapUIInstance.mode === 'full')
    });
  }
  return true;
});
